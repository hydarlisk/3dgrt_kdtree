#pragma once

#include "GBase.h"
#include "GTexture.h"
#include "GCriticalSection.h"

#include <vector>

using namespace std;

/**
 *	Renderer �ȿ��� ����ϴ� Texture �� �����ϴ�
 *	Ŭ����. FreeImage Library �� ����ؼ� jpg ��
 *	�о���δ�.
 *
 *	by graphicsian.
 */
class  GTextureManager
{
private:
	static GTextureManager g_TextureManager;

private:
	vector<GTexture*> m_TextureList;

public:
	GTextureManager(void);
	virtual ~GTextureManager(void);

	static GTextureManager* getInstance();

	void clear();
	int addTexture( const char* imagefile );
	GTexture* getTexture( int textureID );
	void loadAllTexture();
	GTexture* getTextureByIndex( int index );
	int getTextureCount();

	GCriticalSection	m_TextureListCS;
};
