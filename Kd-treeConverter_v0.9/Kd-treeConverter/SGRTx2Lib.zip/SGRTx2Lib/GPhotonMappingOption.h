#pragma once

/**
 *	Photon Mapping ���� �ɼ�
 *
 *	by graphicsian.
 */
#include "GRenderOption.h"

// photon density area �� ���ϴ� ���.
typedef enum {
	
	densityProjectedCircle,				//	projected circle.
	densityAreaPhoton,					//	area photon �̿�.

} enumDensityMethod;

class GPhotonMappingOption : public GRenderOption
{
public:
	int m_iEmitPhotonPerIteration;
	int m_iMaxBound;
	int m_iIteration;

	float m_fSearchRadius;

	float m_fTotalSceneLightPower;
	float m_fGridUnitLength;

	bool m_bDirectIllumByPhotonMap;
	bool m_bSaveDirectPhoton;
	bool m_bGlossyEffectPhotonMap;
	enumDensityMethod m_eDensityMethod;

public:
	GPhotonMappingOption(void);
	~GPhotonMappingOption(void);
};
