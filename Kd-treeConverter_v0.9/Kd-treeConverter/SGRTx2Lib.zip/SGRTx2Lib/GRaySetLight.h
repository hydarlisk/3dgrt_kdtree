#pragma once

#include "GBase.h"
#include "GLight.h"
#include "GPoint.h"

/**
 *	ray �� ���� origin, dir, power sampling ��
 *	�̷���� Light
 */
typedef struct _rayset_ {
	float pos[3];
	float dir[3];
	float power;
} GRaySet;

class GRaySetLight : public GLight
{
private:
	GRaySet *m_pRaySetData;
	int m_iRaySetDataCount;
	bool m_bRandomMode;

public:
	GRaySetLight(void);
	virtual ~GRaySetLight(void);

	virtual void setRaySetData( GRaySet *pRaySet, int count );
	virtual GRaySet *getRaySetData();
	virtual int getRaySetDataCount();

	virtual lightType getLightType() { return typeRaySetLight; }

	void setRandomMode( bool flag ) { m_bRandomMode = flag; }
	bool isRandomMode() { return m_bRandomMode; }

	virtual GError convertToWorldObject();
	virtual GError validObject();
	void makeDebugInfoObject();

	/**
	 *	���� pos �� normal �� ���� ������������ ������ radiance �� ���Ѵ�.
	 */
	virtual GColor getRadiance( GPoint &pos, GVector &normal );

};
