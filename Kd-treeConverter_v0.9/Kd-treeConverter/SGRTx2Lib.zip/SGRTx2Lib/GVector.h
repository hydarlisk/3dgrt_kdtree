//--------------------------------------------------------------------------//
//																			//
//	Vector Ŭ����															//
//																			//
//	Copyright (c) 2005  ������	( sonagi21@naver.com )						//
//																			//
//--------------------------------------------------------------------------//

#pragma once

#include "GBase.h"
#include "GPoint.h"

class GVector
{
public:
	union {
		struct { float x, y, z, w;  };
		struct { float m_Vector[4]; };
	};

public:
	GVector(void)                                            : x(0.0f),     y(0.0f),     z(0.0f),     w(1.0f) { };
	GVector( const GVector &vector )                         : x(vector.x), y(vector.y), z(vector.z), w(1.0f) { };
	GVector( const GPoint &point )                           : x(point.x),  y(point.y),  z(point.z),  w(1.0f) { };
	GVector( float _x, float _y, float _z, float _w = 0.0f ) : x(_x),       y(_y),       z(_z),       w(_w)   { };
	GVector( float v[4] )                                    : x(v[0]),     y(v[1]),     z(v[2]),     w(v[3]) { };
	virtual ~GVector(void)	{}

	float*			GetPointer() { return m_Vector; }
	const float*	getVector();
	void setVector( float sx, float sy, float sz, float sw = 0.0f );	// ���Ͱ� �Է�

	float& operator[] ( int index );
	float getElement( int index );

	float	innerProduct( const GVector &vector );		// ����
	GVector	outerProduct( const GVector &vector );		// ����
	GVector	normalize() const;							// ����ȭ
	float	length();									// ����
	bool	isZero();

	BOOL    operator==( const GVector &vector );		// ���Ͱ� ������. ������ ����� �ǹ��ϴ°� �ƴ϶� �ܼ��� ������ ��� ��ġ�ؾ���
	void    operator= ( const GVector &vector )                { this->x = vector.x; this->y = vector.y; this->z = vector.z; this->w = vector.w; } // ����
	GVector operator+ ( const GVector &vector ) const;	// ����
	GVector operator- ( const GVector &vector ) const;	// ����
	GVector operator- () const;							// ����

	friend GVector operator * ( const GVector& v, const float f ) { return GVector( v.x * f, v.y * f, v.z * f, v.w * f  ); }	// ��Į�� ��
	friend GVector operator * ( const float f, const GVector& v ) { return GVector( v.x * f, v.y * f, v.z * f, v.w * f  ); }	// ��Į�� ��
	friend GVector operator / ( const GVector& v, const float f ) { float invf = 1/f; return GVector( v.x * invf, v.y * invf, v.z * invf, v.w * invf ); }	// ��Į�� ������

	void operator-= ( const GVector &vector );			// ����
	void operator+= ( const GVector &vector );			// ����
	GVector& operator *=( const float f )  { x *= f; y *= f; z *= f; w *= f; return *this; }	                            // ��Į�� ��
	GVector& operator /=( const float f )  { float invf = 1/f; x *= invf; y *= invf; z *= invf; w *= invf; return *this; }	// ��Į�� ������
};
