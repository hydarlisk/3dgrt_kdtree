#pragma once

#include "GBase.h"
#include "GPolygonObject.h"

/**
 *	�ﰢ������ �̷���� Geometry.
 *	by graphicsian.
 */
class GPolygonGeometry : public GPolygonObject
{
public:
	GPolygonGeometry(void);
	~GPolygonGeometry(void);
};
