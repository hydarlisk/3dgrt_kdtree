#include "GSSERayTracerForQueue.h"
#include "GSpatialStructure.h"
#include "GKDTreeStructure.h"
#include "GPointLight.h"
#include "GRenderCommon.h"
		#include "SSERenderPipeline.h"				//yet GRenderCommon.h �� ������
#include "math.h"

#include "GThreadManager.h"
#include "GThreadingOption.h"


// ------------------------------------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////////////////////////////////
// ------------------------------------------------------------------------------------------------

GSSERayTracerForQueue::GSSERayTracerForQueue()
{
	m_iOldSceneNumber = 0;
	m_pSSERenderPipeline = NULL;
	m_pSSESceneData     = NULL;
	m_iSceneTimestamp = -1;
	m_pScene = NULL;
	m_iThreadCount = 0;
}

GSSERayTracerForQueue::~GSSERayTracerForQueue(void)
{
	uninitialize();
}

// ------------------------------------------------------------------------------------------------
// uninitialize()
// ------------------------------------------------------------------------------------------------
void GSSERayTracerForQueue::uninitialize()
{
	if ( m_pSSERenderPipeline ) {
		delete m_pSSERenderPipeline;
		m_pSSERenderPipeline = NULL;
	}

	if ( m_pSSESceneData ) {
		delete m_pSSESceneData;
		m_pSSESceneData = NULL;
	}
}

// ------------------------------------------------------------------------------------------------
// initialize()		: scene ������ �籸���ؾ��Ҷ� �ʱ�ȭ�Ѵ�.
// ------------------------------------------------------------------------------------------------
GError GSSERayTracerForQueue::initialize( GScene *pScene )
{
	GError error;
	m_pScene = pScene;

	bool bModifiedScene  = false;
	bool bModifiedThread = false;

	if ( m_iOldSceneNumber != pScene->getSceneNumber() || 
		 m_iSceneTimestamp != pScene->getGeometryChangeTimestamp() ||
		 m_oldResolution != pScene->getResolution() ) {

		// ----------------------------------------------------------
		// KdTree �� triangle ������ �������ϴ� ���� ����ü ����
		// ----------------------------------------------------------
		if ( m_pSSESceneData ) {
			delete m_pSSESceneData;
		}
		m_pSSESceneData = new SSESceneData(pScene);

		error = pScene->getKDTreeStructure()->makeSSERenderStructureInfo( m_pSSESceneData );
		if ( error != errorNo )
			return error;

		// ----------------------------------------------------------
		// ���� Renderer �� ó���� Scene �� ����Ѵ�.
		// ----------------------------------------------------------
		m_iOldSceneNumber = pScene->getSceneNumber();
		m_iSceneTimestamp = pScene->getGeometryChangeTimestamp();
		m_oldResolution = pScene->getResolution();
		bModifiedScene = true;
	}

	if (m_iThreadCount != m_pScene->getCPUThreadCount()) {
		m_iThreadCount = pScene->getCPUThreadCount();
		bModifiedThread = true;
	}

	if (bModifiedScene) {
		// ----------------------------------------------------------
		// Render Pipeline ����
		// ----------------------------------------------------------
		if ( m_pSSERenderPipeline ) {
			delete m_pSSERenderPipeline;
		}
		m_pSSERenderPipeline = new SSERenderPipelineQ(pScene, m_pSSESceneData);
	}

	return errorNo;
}

// ------------------------------------------------------------------------------------------------
// rendering()
// ------------------------------------------------------------------------------------------------
GError GSSERayTracerForQueue::rendering( GScene *pScene, bool isDebug )
{
	GError error;

	// ----------------------------------------------------------
	//	Scene �� ���� geometry ���¿��� ���Ѱ� �ִ��� üũ�ؼ� �ִٸ�
	//	SpatialStructure �� �籸���Ѵ�.
	// ----------------------------------------------------------
	error = initialize( pScene );
	if ( error != errorNo ) {
		GLogManager::logging( LOG_ERROR, "can't initialize rendering\n" );
		return error;
	}

	// ----------------------------------------------------------
	// PrepareRender ȣ�� : Screen �� Ray �� ����
	// ----------------------------------------------------------
	m_pSSERenderPipeline->PrepareRender(m_iThreadCount);
	m_pSSERenderPipeline->m_TraceQ4x4->ClearIndex();		// ����� �Ⱦ��µ�.. ������ �� �������� NULL �̶� �׷��� ����-.-

	GTimer timer1;
	timer1.start();

	// ----------------------------------------------------------
	// Render()
	// ----------------------------------------------------------
	m_pSSERenderPipeline->Render4x4Q();

	if ( error != errorNo ) {
		GLogManager::logging( LOG_FATAL, "Rendering Error, %s\n", GErrorManager::getGErrorString( error ) );
		return errorNo;
	}

	timer1.end();
	m_pScene->setFPS( 1.0f / timer1.getElapsedTime() );

	GLogManager::logging( LOG_DEBUG, "traceRayFullBounce time : %f sec.\n", timer1.getElapsedTime() );

	return errorNo;
}