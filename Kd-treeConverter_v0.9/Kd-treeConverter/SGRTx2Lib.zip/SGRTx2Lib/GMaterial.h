#pragma once

#include "GBase.h"
#include "GColor.h"

/**
 *	��ü�� Material.
 *	��ü�� ������ ���� material �� ǥ���Ѵ�.
 *
 *	by graphicsian
 */
class  GMaterial
{
public:
	GColor m_Ambient;				//	ambient color
	GColor m_Diffuse;				//	diffuse color
	GColor m_Specular;				//	specular color
	GColor m_Emission;				//	emission color

	//	m_fReflection + m_fTransparency + m_fLocalShading �� 1 �̾�� �Ѵ�.
	//	���� m_fLocalShading ������ = m_fReflection - m_fTransparency;
	float m_fReflection;			//	reflection Ȯ��.
	float m_fTransparency;			//	refraction Ȯ��.

	float m_fRoughness;				//	roughness. 
	float m_fRefractionIndex;		//  ������

public:
	GMaterial(void);
	virtual ~GMaterial(void);

	void setDiffuse( const GColor &diffuse );
	void setAmbient( const GColor &ambient );
	void setSpecular( const GColor &specular );
	void setTransmission( const GColor &trans );
	void setEmission( const GColor &emission );
	void setRoughness( const float &roughness );
	void setReflection( const float &r );
	void setTransparency( const float &r );

	float getReflection()        { return m_fReflection; }
	GColor getDiffuse()          { return m_Diffuse; }
	GColor getSpecular()         { return m_Specular; }
	GColor getTransmission();
	GColor getAmbient()          { return m_Ambient; }
	GColor getEmission()         { return m_Emission; }
	float getRoughness()         { return m_fRoughness; }
	float getRefractionIndex()   { return m_fRefractionIndex; }
	float getTransparency()      { return m_fTransparency; }

	bool validMaterialProperty();
	bool isTransparent();
};