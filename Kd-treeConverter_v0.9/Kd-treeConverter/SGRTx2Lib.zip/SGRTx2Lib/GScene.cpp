#include "GScene.h"
#include "GPolygonObject.h"
#include "GObjectNumberGenerator.h"
#include "GTextureManager.h"
#include "GKDTreeStructure.h"
#include "GBVHStructure.h"
#include "GGridStructure.h"


GScene::GScene(void)
	: m_LoadedCameraCount(0)
{
	m_szSceneName[0] = 0x00;
	m_iSceneNumber = GObjectNumberGenerator::generateSceneNumber();

	m_szVersion[0] = 0x00;
	m_szOutputPath[0] = 0x00;
	m_szTexturePath[0] = 0x00;
	m_szSceneBasePath[0] = 0x00;

	m_Resolution.x = 800;
	m_Resolution.y = 600;
    m_SuperSampling.x = 1;
	m_SuperSampling.y = 1;
	m_RenderingBlock.x = 1;
	m_RenderingBlock.y = 1;

	m_FrontFace = faceCCW;

	m_iGeometryChangeTimestamp = 0;
	m_iLastConvertRenderScene = -1;

	m_LastUseSpatialStructure = USE_NONE;
	m_CurrUseSpatialStructure = USE_KDTREE;
	memset(m_iLastGeomTimestamp_For_SpatialStructure, 0x00, sizeof(m_iLastGeomTimestamp_For_SpatialStructure));

	m_bJittering		= true;
	m_bBackFaceCulling	= false;
	m_bUseTexture		= true;
	m_bLocalShading		= true;
	m_bShadow			= false;
	m_iMaxReflectionDepth = 3;

	m_pImageBuffer = NULL;
	m_pDirectIllumImageBuffer = NULL;
	m_pIndirectIllumImageBuffer = NULL;

	m_iCPUThreadCount = 4;
	m_GPUBlockSize.x = 4;
	m_GPUBlockSize.y = 64;
	m_CPUPacketSize.x = 1;
	m_CPUPacketSize.y = 1;

	m_fFPS = 0.0f;
	m_fFPS2 = 0.0f;

	m_bOpenGLLoadTexture = false;

	m_bKDTreeFileType = SAH;
	m_bKDTreeFileLoad = false;
	m_bKDTreeFileSave = false;
	m_szKDTreeLoadFilePath[0] = 0x00;
	m_szKDTreeSaveFilePath[0] = 0x00;
	m_pKDTree = NULL;
	m_pEmptyKDTree = NULL;
	m_pBVH = NULL;
	m_pGrid= NULL;

	m_bBloomingFilter = false;
	m_fBloomingRadius = 1.0f;
	m_fBloomingWeight = 0.03f;

	m_bAntialiasingFilter = false;
	m_bGrayScaleFilter = false;
	m_bEdgeDetectionFilter = false;
	m_bBlurFilter = false;

	m_AdaptiveSamplingType = adaptiveSubpixel;
	m_bSamplingDebugInfo = false;

	m_AdaptiveSamplingCompareType = COMPARE_PRIMARY_OID | COMPARE_PRIMARY_NORMAL  | COMPARE_PRIMARY_SHADOW | COMPARE_PRIMARY_TEXTURE |
									COMPARE_SECONDARY_OID | COMPARE_SECONDARY_NORMAL | COMPARE_SECONDARY_SHADOW | COMPARE_PRIMARY_TEXTURE |
									COMPARE_ETC_REGION;

	setHighLevelAdaptiveSamplingThreshold();

	m_fOnlyColorThreshold = 0.1f;

	m_bRun10Times = false;
	strcpy(m_szProfileResultPath, "profile.out");
	m_bProfileFlag = false;
	m_bTestFlag = false;
}

GScene::~GScene(void)
{
	/** 
	 *	light �� list �� Ŭ���� �Ѵ�. ���� light object ��
	 *	object list ���� ��� �����Ƿ�, object ������ ������ ���̴�.
	 */
	m_LightList.clear();

	//! delete camera
	//for ( int i = 0; i < (int)m_CameraList.size(); ++i )
	//	delete m_CameraList[i];
	//m_CameraList.clear();

	if ( m_pImageBuffer )
		delete m_pImageBuffer;
	if ( m_pDirectIllumImageBuffer )
		delete m_pDirectIllumImageBuffer;
	if ( m_pIndirectIllumImageBuffer )
		delete m_pIndirectIllumImageBuffer;
	if ( m_pKDTree )
		delete m_pKDTree;
	if ( m_pBVH )
		delete m_pBVH;
	if ( m_pGrid )
		delete m_pGrid;

	clearObject();
}

void GScene::setSceneName( const char* name )
{
	sprintf( m_szSceneName, "%s", name );
}

const char* GScene::getSceneName()
{
	return m_szSceneName;
}

int GScene::getSceneNumber()
{
	return m_iSceneNumber;
}

bool GScene::initalize()
{
	GTextureManager::getInstance()->loadAllTexture();

	return true;
}

void GScene::setKdTreeFileType( int type )
{
	m_bKDTreeFileType = type;
}

int GScene::getKdTreeFileType()
{
	return m_bKDTreeFileType;
}

void GScene::setKdTreeFileLoad( bool flag )
{
	m_bKDTreeFileLoad = flag;
}

bool GScene::isKdTreeFileLoad()
{
	return m_bKDTreeFileLoad;
}
	
void GScene::setKdTreeFileSave( bool flag )
{
	m_bKDTreeFileSave = flag;
}

bool GScene::isKdTreeFileSave()
{
	return m_bKDTreeFileSave;
}

void GScene::setKdTreeLoadFilePath( const char* path )
{
	strncpy( m_szKDTreeLoadFilePath, path, MAX_PATH_LENGTH );
	m_szKDTreeLoadFilePath[ MAX_PATH_LENGTH - 1 ] = 0x00;
}

const char* GScene::getKdTreeLoadFilePath()
{
	return m_szKDTreeLoadFilePath;
}

void GScene::setKdTreeSaveFilePath( const char* path )
{
	strncpy( m_szKDTreeSaveFilePath, path, MAX_PATH_LENGTH );
	m_szKDTreeSaveFilePath[ MAX_PATH_LENGTH - 1 ] = 0x00;
}

const char* GScene::getKdTreeSaveFilePath()
{
	return m_szKDTreeSaveFilePath;
}

void GScene::setEnableJittering( bool flag )
{
	m_bJittering = flag;
}

bool GScene::isEnableJittering()
{
	return m_bJittering;
}
	
void GScene::setEnableShadow( bool flag )
{
	m_bShadow = flag;
}

bool GScene::isEnableShadow()
{
	return m_bShadow;
}

void GScene::setCPUThreadCount( int count )
{
	m_iCPUThreadCount = count;
}

int GScene::getCPUThreadCount()
{
	return m_iCPUThreadCount;
}

void GScene::setCPUPacketSize( int x, int y )
{
	m_CPUPacketSize.x = x;
	m_CPUPacketSize.y = y;
}

void GScene::setPrimaryOIDRegionColorThreshold( float f )
{
	m_fPrimaryOIDRegionColorThreshold = f;
}

float GScene::getPrimaryOIDRegionColorThreshold()
{
	return m_fPrimaryOIDRegionColorThreshold;
}

void GScene::setPrimaryNormalRegionColorThreshold( float f )
{
	m_fPrimaryNormalRegionColorThreshold = f;
}

float GScene::getPrimaryNormalRegionColorThreshold()
{
	return m_fPrimaryNormalRegionColorThreshold;
}

void GScene::setPrimaryShadowRegionColorThreshold( float f )
{
	m_fPrimaryShadowRegionColorThreshold = f;
}

float GScene::getPrimaryShadowRegionColorThreshold()
{
	return m_fPrimaryShadowRegionColorThreshold;
}

void GScene::setPrimaryTextureRegionColorThreshold( float f )
{
	m_fPrimaryTextureRegionColorThreshold = f;
}

float GScene::getPrimaryTextureRegionColorThreshold()
{
	return m_fPrimaryTextureRegionColorThreshold;
}

void GScene::setSecondaryOIDRegionColorThreshold( float f )
{
	m_fSecondaryOIDRegionColorThreshold = f;
}

float GScene::getSecondaryOIDRegionColorThreshold()
{
	return m_fSecondaryOIDRegionColorThreshold;
}

void GScene::setSecondaryNormalRegionColorThreshold( float f )
{
	m_fSecondaryNormalRegionColorThreshold = f;
}

float GScene::getSecondaryNormalRegionColorThreshold()
{
	return m_fSecondaryNormalRegionColorThreshold;
}

void GScene::setSecondaryShadowRegionColorThreshold( float f )
{
	m_fSecondaryShadowRegionColorThreshold = f;
}

float GScene::getSecondaryShadowRegionColorThreshold()
{
	return m_fSecondaryShadowRegionColorThreshold;
}

void GScene::setSecondaryTextureRegionColorThreshold( float f )
{
	m_fSecondaryTextureRegionColorThreshold = f;
}

float GScene::getSecondaryTextureRegionColorThreshold()
{
	return m_fSecondaryTextureRegionColorThreshold;
}

void GScene::setEtcRegionColorThreshold( float f )
{
	m_fEtcRegionColorThreshold = f;
}

float GScene::getEtcRegionColorThreshold()
{
	return m_fEtcRegionColorThreshold;
}

void GScene::setOnlyColorThreshold( float f )
{
	m_fOnlyColorThreshold = f;
}

float GScene::getOnlyColorThreshold()
{
	return m_fOnlyColorThreshold;
}

void GScene::setAdaptiveDetectionStageTime( float t )
{
	m_fAdaptiveDetectionStageTime = t;
}

float GScene::getAdaptiveDetectionStageTime()
{
	return m_fAdaptiveDetectionStageTime;
}

void GScene::setAdaptiveRayRate( float r )
{
	m_fAdaptiveRayRate = r;
}

float GScene::getAdaptiveRayRate()
{
	return m_fAdaptiveRayRate;
}


void GScene::setLowLevelAdaptiveSamplingThreshold()
{
	setPrimaryOIDRegionColorThreshold( 0.05f );
	setPrimaryNormalRegionColorThreshold( 0.06f );
	setPrimaryShadowRegionColorThreshold( 1.0f );
	setPrimaryTextureRegionColorThreshold( 1.0f );

	setSecondaryOIDRegionColorThreshold( 0.05f );
	setSecondaryNormalRegionColorThreshold( 0.06f );
	setSecondaryShadowRegionColorThreshold( 1.0f );
	setSecondaryTextureRegionColorThreshold( 1.0f );

	setEtcRegionColorThreshold( 1.0f );

	setAdaptiveSamplingCompareType( 
		COMPARE_PRIMARY_OID | COMPARE_PRIMARY_NORMAL | COMPARE_PRIMARY_SHADOW | COMPARE_PRIMARY_TEXTURE |
		COMPARE_SECONDARY_OID | COMPARE_SECONDARY_NORMAL | COMPARE_SECONDARY_SHADOW | COMPARE_SECONDARY_TEXTURE |
		COMPARE_ETC_REGION );
}

void GScene::setGoodLevelAdaptiveSamplingThreshold()
{
	setPrimaryOIDRegionColorThreshold( 0.05f );
	setPrimaryNormalRegionColorThreshold( 0.06f );
	setPrimaryShadowRegionColorThreshold( 0.06f );
	setPrimaryTextureRegionColorThreshold( 0.6f );

	setSecondaryOIDRegionColorThreshold( 0.05f );
	setSecondaryNormalRegionColorThreshold( 0.06f );
	setSecondaryShadowRegionColorThreshold( 0.06f );
	setSecondaryTextureRegionColorThreshold( 0.6f );

	setEtcRegionColorThreshold( 0.6f );

	setAdaptiveSamplingCompareType( 
		COMPARE_PRIMARY_OID | COMPARE_PRIMARY_NORMAL | COMPARE_PRIMARY_SHADOW | COMPARE_PRIMARY_TEXTURE |
		COMPARE_SECONDARY_OID | COMPARE_SECONDARY_NORMAL | COMPARE_SECONDARY_SHADOW | COMPARE_SECONDARY_TEXTURE |
		COMPARE_ETC_REGION );
}

void GScene::setHighLevelAdaptiveSamplingThreshold()
{
	setPrimaryOIDRegionColorThreshold( 0.05f );
	setPrimaryNormalRegionColorThreshold( 0.06f );
	setPrimaryShadowRegionColorThreshold( 0.06f );
	setPrimaryTextureRegionColorThreshold( 0.6f );

	setSecondaryOIDRegionColorThreshold( 0.05f );
	setSecondaryNormalRegionColorThreshold( 0.06f );
	setSecondaryShadowRegionColorThreshold( 0.06f );
	setSecondaryTextureRegionColorThreshold( 0.6f );

	setEtcRegionColorThreshold( 0.6f );

	setAdaptiveSamplingCompareType( 
		COMPARE_PRIMARY_OID | COMPARE_PRIMARY_NORMAL | COMPARE_PRIMARY_SHADOW | COMPARE_PRIMARY_TEXTURE |
		COMPARE_SECONDARY_OID | COMPARE_SECONDARY_NORMAL | COMPARE_SECONDARY_SHADOW | COMPARE_SECONDARY_TEXTURE |
		COMPARE_ETC_REGION );
}

void GScene::setVeryHighLevelAdaptiveSamplingThreshold()
{
	setPrimaryOIDRegionColorThreshold( 0.05f );
	setPrimaryNormalRegionColorThreshold( 0.06f );
	setPrimaryShadowRegionColorThreshold( 0.06f );
	setPrimaryTextureRegionColorThreshold( 0.07f );

	setSecondaryOIDRegionColorThreshold( 0.05f );
	setSecondaryNormalRegionColorThreshold( 0.06f );
	setSecondaryShadowRegionColorThreshold( 0.06f );
	setSecondaryTextureRegionColorThreshold( 0.07f );

	setEtcRegionColorThreshold( 0.07f );

	setAdaptiveSamplingCompareType( 
		COMPARE_PRIMARY_OID | COMPARE_PRIMARY_NORMAL | COMPARE_PRIMARY_SHADOW | COMPARE_PRIMARY_TEXTURE |
		COMPARE_SECONDARY_OID | COMPARE_SECONDARY_NORMAL | COMPARE_SECONDARY_SHADOW | COMPARE_SECONDARY_TEXTURE |
		COMPARE_ETC_REGION );
}


void GScene::setVeryHighLevelExceptTextureAdaptiveSamplingThreshold( float oidColor, float tColor )
{
	setPrimaryOIDRegionColorThreshold( oidColor );
	setPrimaryNormalRegionColorThreshold( 0.06f );
	setPrimaryShadowRegionColorThreshold( 0.06f );
	setPrimaryTextureRegionColorThreshold( tColor );

	setSecondaryOIDRegionColorThreshold( oidColor );
	setSecondaryNormalRegionColorThreshold( 0.06f );
	setSecondaryShadowRegionColorThreshold( 0.06f );
	setSecondaryTextureRegionColorThreshold( tColor );

	setEtcRegionColorThreshold( tColor );

	setAdaptiveSamplingCompareType( 
		COMPARE_PRIMARY_OID | COMPARE_PRIMARY_NORMAL | COMPARE_PRIMARY_SHADOW | COMPARE_PRIMARY_TEXTURE |
		COMPARE_SECONDARY_OID | COMPARE_SECONDARY_NORMAL | COMPARE_SECONDARY_SHADOW | COMPARE_SECONDARY_TEXTURE |
		COMPARE_ETC_REGION );
}

//
//void GScene::setLowLevelAdaptiveSamplingThreshold()
//{
//	setPrimaryOIDRegionColorThreshold( 0.0f );
//	setPrimaryNormalRegionColorThreshold( 0.3f );
//	setPrimaryShadowRegionColorThreshold( 0.3f );
//	setPrimaryTextureRegionColorThreshold( 1.0f );
//
//	setSecondaryOIDRegionColorThreshold( 0.0f );
//	setSecondaryNormalRegionColorThreshold( 0.3f );
//	setSecondaryShadowRegionColorThreshold( 0.3f );
//	setSecondaryTextureRegionColorThreshold( 1.0f );
//
//	setEtcRegionColorThreshold( 1.0f );
//
//	setAdaptiveSamplingCompareType( 
//		COMPARE_PRIMARY_OID | COMPARE_PRIMARY_NORMAL | COMPARE_PRIMARY_SHADOW | COMPARE_PRIMARY_TEXTURE |
//		COMPARE_SECONDARY_OID | COMPARE_SECONDARY_NORMAL | COMPARE_SECONDARY_SHADOW | COMPARE_SECONDARY_TEXTURE | COMPARE_ETC_REGION );
//}
//
//void GScene::setGoodLevelAdaptiveSamplingThreshold()
//{
//	setPrimaryOIDRegionColorThreshold( 0.1f );
//	setPrimaryNormalRegionColorThreshold( 0.1f );
//	setPrimaryShadowRegionColorThreshold( 0.1f );
//	setPrimaryTextureRegionColorThreshold( 0.5f );
//
//	setSecondaryOIDRegionColorThreshold( 0.1f );
//	setSecondaryNormalRegionColorThreshold( 0.1f );
//	setSecondaryShadowRegionColorThreshold( 0.1f );
//	setSecondaryTextureRegionColorThreshold( 0.5f );
//
//	setEtcRegionColorThreshold( 0.5f );
//
//	setAdaptiveSamplingCompareType( 
//		COMPARE_PRIMARY_OID | COMPARE_PRIMARY_NORMAL | COMPARE_PRIMARY_SHADOW | COMPARE_PRIMARY_TEXTURE |
//		COMPARE_SECONDARY_OID | COMPARE_SECONDARY_NORMAL | COMPARE_SECONDARY_SHADOW | COMPARE_SECONDARY_TEXTURE |
//		COMPARE_ETC_REGION );
//}
//
//void GScene::setHighLevelAdaptiveSamplingThreshold()
//{
//	setPrimaryOIDRegionColorThreshold( 0.05f );
//	setPrimaryNormalRegionColorThreshold( 0.1f );
//	setPrimaryShadowRegionColorThreshold( 0.1f );
//	setPrimaryTextureRegionColorThreshold( 0.3f );
//
//	setSecondaryOIDRegionColorThreshold( 0.05f );
//	setSecondaryNormalRegionColorThreshold( 0.1f );
//	setSecondaryShadowRegionColorThreshold( 0.1f );
//	setSecondaryTextureRegionColorThreshold( 0.3f );
//
//	setEtcRegionColorThreshold( 0.3f );
//
//	setAdaptiveSamplingCompareType( 
//		COMPARE_PRIMARY_OID | COMPARE_PRIMARY_NORMAL | COMPARE_PRIMARY_SHADOW | COMPARE_PRIMARY_TEXTURE |
//		COMPARE_SECONDARY_OID | COMPARE_SECONDARY_NORMAL | COMPARE_SECONDARY_SHADOW | COMPARE_SECONDARY_TEXTURE |
//		COMPARE_ETC_REGION );
//}
//
//void GScene::setVeryHighLevelAdaptiveSamplingThreshold()
//{
//	setPrimaryOIDRegionColorThreshold( 0.05f );
//	setPrimaryNormalRegionColorThreshold( 0.1f );
//	setPrimaryShadowRegionColorThreshold( 0.1f );
//	setPrimaryTextureRegionColorThreshold( 0.15f );
//
//	setSecondaryOIDRegionColorThreshold( 0.05f );
//	setSecondaryNormalRegionColorThreshold( 0.1f );
//	setSecondaryShadowRegionColorThreshold( 0.1f );
//	setSecondaryTextureRegionColorThreshold( 0.15f );
//
//	setEtcRegionColorThreshold( 0.15f );
//
//	setAdaptiveSamplingCompareType( 
//		COMPARE_PRIMARY_OID | COMPARE_PRIMARY_NORMAL | COMPARE_PRIMARY_SHADOW | COMPARE_PRIMARY_TEXTURE |
//		COMPARE_SECONDARY_OID | COMPARE_SECONDARY_NORMAL | COMPARE_SECONDARY_SHADOW | COMPARE_SECONDARY_TEXTURE |
//		COMPARE_ETC_REGION );
//}

void GScene::setAdaptiveSamplingType( enumAdaptiveSamplingType type )
{
	m_AdaptiveSamplingType = type;
}

enumAdaptiveSamplingType GScene::getAdaptiveSamplingType()
{
	return m_AdaptiveSamplingType;
}
	
void GScene::setAdaptiveSamplingCompareType( int compare )
{
	m_AdaptiveSamplingCompareType = compare;
}

int GScene::getAdaptiveSamplingCompareType()
{
	return m_AdaptiveSamplingCompareType;
}

void GScene::setEnableSamplingDebugInfo( bool flag )
{
	m_bSamplingDebugInfo = flag;
}

bool GScene::isEnableSamplingDebugInfo()
{
	return m_bSamplingDebugInfo;
}
	
void GScene::setEnableLocalShading( bool flag )
{
	m_bLocalShading = flag;
}

bool GScene::isEnableLocalShading()
{
	return m_bLocalShading;
}

GDimension GScene::getCPUPacketSize()
{
	return m_CPUPacketSize;
}

void GScene::setGPUBlockSize( int x, int y )
{
	m_GPUBlockSize.x = x;
	m_GPUBlockSize.y = y;
}

GDimension GScene::getGPUBlockSize()
{
	return m_GPUBlockSize;
}

void GScene::setUseAntialiasingFilter( bool flag )
{
	m_bAntialiasingFilter = flag;
}

bool GScene::isUseAntialiasingFilter()
{
	return m_bAntialiasingFilter;
}
	
void GScene::setUseBlurFilter( bool flag )
{
	m_bBlurFilter = flag;
}

bool GScene::isUseBlurFilter()
{
	return m_bBlurFilter;
}

void GScene::setUseEdgeDetectionFilter( bool flag )
{
	m_bEdgeDetectionFilter = flag;
}

bool GScene::isUseEdgeDetectionFilter()
{
	return m_bEdgeDetectionFilter;
}

void GScene::setUseGrayScaleFilter( bool flag )
{
	m_bGrayScaleFilter = flag;
}

bool GScene::isUseGrayScaleFilter()
{
	return m_bGrayScaleFilter;
}

void GScene::setOpenGLLoadTexture( bool flag )
{
	m_bOpenGLLoadTexture = flag;
}

bool GScene::isOpenGLLoadTexture()
{
	return m_bOpenGLLoadTexture;
}

float GScene::getFPS()
{
	return m_fFPS;
}

void GScene::setFPS( float fps )
{
	m_fFPS = fps;
}

float GScene::getFPS2()
{
	return m_fFPS2;
}

void GScene::setFPS2( float fps )
{
	m_fFPS2 = fps;
}

void GScene::setBloomingFilter( bool flag )
{
	m_bBloomingFilter = flag;
}

bool GScene::isBloomingFilter()
{
	return m_bBloomingFilter;
}

void GScene::setBloomingRadius( float radius )
{
	m_fBloomingRadius = radius;
}

float GScene::getBloomingRadius()
{
	return m_fBloomingRadius;
}

void GScene::setBloomingWeight( float w )
{
	m_fBloomingWeight = w;
}

float GScene::getBloomingWeight()
{
	return m_fBloomingWeight;
}

void GScene::setRenderingBlock( int x, int y )
{
	m_RenderingBlock.x = x;
	m_RenderingBlock.y = y;
}

GDimension GScene::getRenderingBlock()
{
	return m_RenderingBlock;
}

/**
 *	Scene �� ��� Object �� �����Ѵ�.
 */
void GScene::clearObject()
{
	vector<GObject*>::iterator iter;
	for ( iter = m_ObjectList.begin(); iter != m_ObjectList.end(); ++iter ) {
		delete (*iter);
	}
	m_ObjectList.clear();
	m_SelecteGObjectList.clear();
}

/** debugging ���� object ������ */
void GScene::clearDebugObject()
{
	vector<GObject*>::iterator iter;

	for ( iter = m_ObjectList.begin(); iter < m_ObjectList.end(); ) {
		if ( (*iter)->isDebugObject() ) {
			delete (*iter);
			iter = m_ObjectList.erase( iter );
		} else {
			++iter;
		}
	}

	m_SelecteGObjectList.clear();
}

/**
 *	Scene �� Object �� �߰��Ѵ�.
 *	�ش� Object �� �ʿ������� ���ý�Ű��, valid �� object
 *	������ Ȯ���Ѵ�.
 */
GError GScene::addObject( GObject* pObject )
{
	GError error = pObject->validObject();

	if ( error != errorNo )
		return error;

	m_ObjectListCS.lock();
	m_ObjectList.push_back( pObject );
	m_ObjectListCS.unlock();

	if ( !pObject->isDebugObject() )
		m_iGeometryChangeTimestamp++;

	return errorNo;
}

/**
 *	Scene ���� Object �� �����Ѵ�.
 */
void GScene::removeObject( GObject* pObject )
{
	deselectAllObject();

	m_ObjectListCS.lock();
	vector<GObject*>::iterator iter;
	for ( iter = m_ObjectList.begin(); iter != m_ObjectList.end(); ++iter ) {
		if ( *iter == pObject ) {
			if ( !pObject->isDebugObject() )
				m_iGeometryChangeTimestamp++;
			delete pObject;
			m_ObjectList.erase( iter );
			break;
		}
	}
	m_ObjectListCS.unlock();
}

/**
 *	name �̸��� ���� object �� �����Ѵ�.
 */
void GScene::removeObject( const char* name )
{
	deselectAllObject();

	m_ObjectListCS.lock();
	vector<GObject*>::iterator iter;
	for ( iter = m_ObjectList.begin(); iter != m_ObjectList.end(); ++iter ) {
		if ( _stricmp( name, (*iter)->getName() ) == 0 ) {
			if ( !(*iter)->isDebugObject() )
				m_iGeometryChangeTimestamp++;
			delete (*iter);
			m_ObjectList.erase( iter );
			break;
		}
	}
	m_ObjectListCS.unlock();

}




GObject* GScene::getObject( int index )
{
	if ( index < 0 || index >= (int)m_ObjectList.size() )
		return NULL;
	return m_ObjectList[index];
}

int GScene::getObjectCount()
{
	return (int)m_ObjectList.size();
}

/**
 *	���� Scene �� ��� ��ü ����� �����Ѵ�.
 */
const vector<GObject*>* GScene::getObjectList()
{
	return &m_ObjectList;
}
/**
 *	pObject ��ü�� ���� ��Ͽ� �߰��Ѵ�.
 *	�̹� �ִٸ� �߰����� �ʴ´�.
 */
void GScene::selectObject( GObject *pObject )
{
	if ( pObject == NULL ) 
		return;

	for ( int i = 0; i < (int)m_SelecteGObjectList.size(); ++i ) {
		if ( m_SelecteGObjectList[i] == pObject )
			return;
	}
	
	pObject->setSelected( true );
	m_SelecteGObjectList.push_back( pObject );
}

/**
 *	���� Scene ���� ���õ� ��ü�� ����.
 */
int GScene::getSelectedGObjectCount()
{
	return (int)m_SelecteGObjectList.size();
}

/**
 *	���� Scene ���� ���õ� ��ü�� �����Ѵ�.
 *	�������� �����ߴٸ� ���� ù��° �͸� ����.
 *	��� ��ü�� �Ѱܹ������� getSelectedGObjectList() �Լ��� ���.
 */
GObject* GScene::getSelectedGObject()
{
	if ( (int)m_SelecteGObjectList.size() > 0 ) {
		return m_SelecteGObjectList[0];
	}
	return NULL;
}

/**
 *	���õ� ��� ��ü�� deselect ��Ų��.
 *	�� object �� selected �� false �� ������Ų��.
 */
void GScene::deselectAllObject()
{
	for ( int i = 0; i < (int)m_SelecteGObjectList.size(); ++i ) {
		m_SelecteGObjectList[i]->setSelected( false );
	}
	m_SelecteGObjectList.clear();
}

/**
 *	��ü�� deselect ��Ų��.
 */
void GScene::deselectObject( GObject* pObject )
{
	if ( pObject == NULL )
		return;
	vector<GObject*>::iterator iter;
	for ( iter = m_SelecteGObjectList.begin(); iter != m_SelecteGObjectList.end(); ++iter ) {
		if ( (*iter) == pObject ) {
			pObject->setSelected( false );
			m_SelecteGObjectList.erase( iter );
			break;
		}
	}
}

/**
 *	���� Scene ���� ���õ� ��ü ����� �����Ѵ�.
 */
vector<GObject*>* const GScene::getSelectedGObjectList()
{
	return &m_SelecteGObjectList;
}

/**
 *	object Number �� �ش��ϴ� Object �� �����Ѵ�.
 */
GObject* GScene::getObjectByNumber( int objectNumber )
{
	for ( int i = 0; i < (int)m_ObjectList.size(); ++i ) {
		if ( m_ObjectList[i]->getObjectNumber() == objectNumber )
			return m_ObjectList[i];
	}
	return NULL;
}

/**
*  center of selected objects
*/
GVector GScene::getCenterOfSelectedGObjects()
{
	GVector Center( 0.0f, 0.0f, 0.0f, 1.0f );

	vector<GObject*>::iterator iter;
	for( iter = m_SelecteGObjectList.begin(); iter != m_SelecteGObjectList.end(); ++iter )
	{
		GBoundingBox *BoundingBox = (*iter)->getBoundingBox();
		Center += *(*iter)->getMatrix() * (( BoundingBox->getMin() + BoundingBox->getMax() ) * 0.5f);
	}
	if( getSelectedGObjectCount() == 0 )
		return GVector( 0.0f, 0.0f, 0.0f, 1.0f );
	Center *= 1.0f/float( getSelectedGObjectCount() );
	return Center;
}

GBoundingBox GScene::getBoundingBoxOfSelectedGObjects()
{
	GVector Min( 1.0e+030f, 1.0e+030f, 1.0e+030f, 1.0f );
	GVector Max( -1.0e+030f, -1.0e+030f, -1.0e+030f, 1.0f );

	if( getSelectedGObjectCount() == 0 )
		return GBoundingBox( GVector(0.0f, 0.0f, 0.0f, 1.0f), GVector(0.0f, 0.0f, 0.0f, 1.0f) );

	vector<GObject*>::iterator iter;
	for( iter = m_SelecteGObjectList.begin(); iter != m_SelecteGObjectList.end(); ++iter )
	{
		GBoundingBox *BoundingBox = (*iter)->getBoundingBox();
		
		for( int i = 0; i < 3; i ++ )
		{
			if( BoundingBox->getMin().GetPointer()[i] < Min.GetPointer()[i] )
				Min.GetPointer()[i] = BoundingBox->getMin().GetPointer()[i];
			if( BoundingBox->getMax().GetPointer()[i] > Max.GetPointer()[i] )
				Max.GetPointer()[i] = BoundingBox->getMax().GetPointer()[i];
		}
	}
	return GBoundingBox( Min, Max );
}
	
/**
 *	Light �߰�. Object ���� �߰��Ѵ�.
 */
void GScene::addLight( GLight *pLight )
{
	m_ObjectListCS.lock();
	m_LightList.push_back( pLight );
	m_ObjectList.push_back( pLight );
	m_iGeometryChangeTimestamp++;
	m_ObjectListCS.unlock();
}

/**
 *	Light ��� ��������
 */
const vector<GLight*>* GScene::getLightList()
{
	return &m_LightList;
}

void GScene::addCamera( GCamera *pCamera )
{
	m_CameraList.push_back( pCamera );
}

const vector<GCamera*>* GScene::getCameraList()
{
	return &m_CameraList;
}

void GScene::setVersion( const char* version )
{
	strncpy( m_szVersion, version, 1000 );
	m_szVersion[ 1000 ] = 0x00;
}

const char* GScene::getVersion()
{
	return m_szVersion;
}
	
void GScene::setResolution( int width, int height )
{
	m_Resolution.x = width;
	m_Resolution.y = height;
}

GDimension GScene::getResolution()
{
	return m_Resolution;
}

void GScene::setSuperSampling( int x, int y )
{
	m_SuperSampling.x = x;
	m_SuperSampling.y = y;
}

void GScene::setMaxReflectionDepth( int depth )
{
	m_iMaxReflectionDepth = depth;
}

int GScene::getMaxReflectionDepth()
{
	return m_iMaxReflectionDepth;
}

GDimension GScene::getSuperSampling()
{
	return m_SuperSampling;
}

void GScene::setOutputPath( const char* path )
{
	strncpy( m_szOutputPath, path, MAX_PATH_LENGTH );
	m_szOutputPath[ MAX_PATH_LENGTH - 1 ] = 0x00;
}

void GScene::setTexturePath( const char* path )
{
	strncpy( m_szTexturePath, path, MAX_PATH_LENGTH );
	m_szTexturePath[ MAX_PATH_LENGTH - 1 ] = 0x00;
}

const char* GScene::getOutputPath()
{
	return m_szOutputPath;
}

const char* GScene::getTexturePath()
{
	return m_szTexturePath;
}

void GScene::setFrontFace( enumFrontFace face )
{
	m_FrontFace = face;
}

enumFrontFace GScene::getFrontFace()
{
	return m_FrontFace;
}

GCamera* GScene::getRenderCamera()
{
	return &m_RenderCamera;
}

GCamera* GScene::getInitRenderCamera()
{
	return &m_InitRenderCamera;
}

GTextureManager *GScene::getTextureManager()
{
	return GTextureManager::getInstance();
}

void GScene::setRenderCamera( const GCamera* pCamera )
{
	/** ���ú��� */
	m_RenderCamera = (*pCamera);
}

void GScene::setInitRenderCamera( const GCamera* pCamera )
{
	/** ���ú��� */
	m_InitRenderCamera = (*pCamera);
}

void GScene::setGlobalAmbient( GColor& color )
{
	m_globalAmbient = color;
}

GColor GScene::getGlobalAmbient()
{
	return m_globalAmbient;
}

GImageBuffer* GScene::getImageBuffer()
{
	return m_pImageBuffer;
}

GImageBuffer* GScene::getDirectIllumImageBuffer()
{
	return m_pDirectIllumImageBuffer;
}

GImageBuffer* GScene::getIndirectIllumImageBuffer()
{
	return m_pIndirectIllumImageBuffer;
}

GError GScene::convertRenderScene()
{
	GError error;

	/**
	 *	Rendering ����� ������ Image Buffer �� �����.
	 *	���� screen size �� ���������� ���� ����.
	 */
	if ( m_pImageBuffer == NULL || m_pImageBuffer->getWidth() != m_Resolution.x ||
		 m_pImageBuffer->getWidth() != m_Resolution.y ) {
		
		if ( m_pImageBuffer != NULL )
			delete m_pImageBuffer;
		m_pImageBuffer = new GImageBuffer( m_Resolution.x, m_Resolution.y );

		if ( m_pDirectIllumImageBuffer != NULL )
			delete m_pDirectIllumImageBuffer;
		m_pDirectIllumImageBuffer = new GImageBuffer( m_Resolution.x, m_Resolution.y );

		if ( m_pIndirectIllumImageBuffer != NULL )
			delete m_pIndirectIllumImageBuffer;
		m_pIndirectIllumImageBuffer = new GImageBuffer( m_Resolution.x, m_Resolution.y );

	}

	/**
	 *	������ ������ Spatial structure �� ���������� ����,
	 *	������ ��ȯ�� ���Ŀ��� geometry ���������� ���� ��� ����
	 *	�� �� ��ǥ�躯ȯ �� Spatial structure �籸��
	 */
	if (m_iLastConvertRenderScene == m_iGeometryChangeTimestamp) {
		if (m_iLastGeomTimestamp_For_SpatialStructure[m_CurrUseSpatialStructure] == m_iGeometryChangeTimestamp)
			return errorNo;
	}

	/** 
	 *	object ( light ���� ) �� ��� world ��ǥ��� ������. 
	 */
	for ( int i = 0; i < (int) m_ObjectList.size(); ++i ) {
		if ( ( error = m_ObjectList[ i ]->convertToWorldObject() ) != errorNo ) {
			return error;
		}
	}

	// ~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~
	// USE_KDTREE
	// ~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~
	if ( m_CurrUseSpatialStructure == USE_KDTREE ) {

		if ( m_pKDTree ) delete m_pKDTree;
		m_pKDTree = new GKDTreeStructure( this );

		GKDTreeOption *kdtree_option = new GKDTreeOption();	// �ӽ�
		//kdtree_option->LoadFile()
		m_pKDTree->setKDTreeOption( kdtree_option );

		bool bKDTreeNewBuild = true;

		// �̹� ������ KDTree �� ���Ͽ� �ִٸ� ���Ϸκ��� KDTree �� �д´�
		if ( m_bKDTreeFileLoad ) {
			bKDTreeNewBuild = !(m_pKDTree->loadStructureFromFile( m_szKDTreeLoadFilePath ));
		}
		
		if ( bKDTreeNewBuild ) {
			// KDTree �� �����Ѵ�.
			if ( m_pKDTree->initialize() != errorNo ) {
				return errorKDTree;
			}
		}

		// ������ KDTree �� ���Ͽ� �����Ѵ�
		if ( m_bKDTreeFileSave ) {
			if ( m_bKDTreeFileType == SAH ) {
				// SAH �� ���
				if ( bKDTreeNewBuild ) {
					// ���� SAH �� ������ų�
					m_pKDTree->saveStructureToFile( m_szKDTreeSaveFilePath );
				} else if ( strcmp(m_szKDTreeSaveFilePath, m_szKDTreeLoadFilePath) != 0 ) {
					// Ȥ�� SAH �� �ε�������, �����ϴ� �����̸��� �ٸ� ���
					m_pKDTree->saveStructureToFile( m_szKDTreeSaveFilePath );
				}
			} else if (m_bKDTreeFileType == EMPTY_SAH) {
				// EMPTY_SAH �� ���
				m_pKDTree->saveStructureToFile( m_szKDTreeSaveFilePath );
			}
		}
	}
	// ~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~
	// USE_BVH
	// ~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~
	else if( m_CurrUseSpatialStructure == USE_BVH ) {

		if ( m_pBVH ) delete m_pBVH;
		m_pBVH = new GBVHStructure( this );

		if ( m_pBVH->initialize() != errorNo ) {
			return errorKDTree;
		}
	}
	// ~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~
	// USE_GRID
	// ~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~
	else if ( m_CurrUseSpatialStructure == USE_GRID ) {

		if(m_pGrid) delete m_pGrid;

		m_pGrid = new GGridStructure( this );
		if( m_pGrid->initialize() != errorNo ){
			return errorUnknown;//���߿� ���� �߰� �� ��.
		}
	}

	m_LastUseSpatialStructure = m_CurrUseSpatialStructure;
	m_iLastConvertRenderScene = m_iGeometryChangeTimestamp;
	m_iLastGeomTimestamp_For_SpatialStructure[m_CurrUseSpatialStructure] = m_iGeometryChangeTimestamp;

	return errorNo;
}

/**
 * Empty KD-Tree �� ����.
*/
GError GScene::buildEmptyKdTree()
{
	if( m_pKDTree != NULL )
		delete m_pKDTree;

	if( m_pEmptyKDTree != NULL )
		delete m_pEmptyKDTree;

	//m_pEmptyKDTree = new GKDTreeStructure();
	// ��� : m_pEmptyKDTree

	return errorNo;
}

/**
 * Object �� KD-Tree �� ����.
 * Empty KD-Tree �� ���� ��� ��ü scene �� ���ؼ� �����.
 * Empty KD-Tree �� ������ �ϸ� �ȵ�.
*/
GError GScene::buildObjectKdTree()
{
	if( m_pKDTree != NULL )
		delete m_pKDTree;

	if( m_pEmptyKDTree )
	{
		// Object �� ���ؼ� ����
	}
	else
	{
		// ��ü scene �� ���ؼ� ����

	}

	//m_pKDTree = new GKDTreeStructure();
	// ��� : m_pKDTree

	return errorNo;
}

/**
 *	KDTree �� �����Ѵ�.
 */
GKDTreeStructure *GScene::getKDTreeStructure()
{
	return m_pKDTree;
}

/**
 *	BVH �� �����Ѵ�.
 */
GBVHStructure* GScene::getBVHStructure()
{
	return m_pBVH;
}

/**
 *	Grid �� �����Ѵ�.
 */
GGridStructure *GScene::getGridStructure(void)
{
	return m_pGrid;
}

void GScene::setUseSpatialStructure( enumSpatialStructureType type )
{
	m_CurrUseSpatialStructure = type;
}

/**
 *	Scene ���� ��ü���� intersection �� �����ؾ� �ϰ�,
 *	trianglulation �� �����ϴ� object �� GTriangleWrapperList ��
 *	����� �����Ѵ�.
 */
GTriangleWrapperList *GScene::createSceneTriangleList( GBoundingBox &bbox )
{
	int totalCount = 0;
	GTriangleWrapperList *pList = new GTriangleWrapperList();
	GPolygonObject* pTriangleObject = NULL;

	bbox.setMax( GVector( -1000000.0f, -1000000.0f, -1000000.0f ) );
	bbox.setMin( GVector( 1000000.0f, 1000000.0f, 1000000.0f ) );

	/**
	 *	Scene ���� Object ��κ��� �ﰢ�� ������ ���´�.
	 *	1. ���� �� �ﰢ���� ������ ���Ѵ�.
	 */
	for ( int i = 0; i < (int) m_ObjectList.size(); ++i ) {

		pTriangleObject = (GPolygonObject*) m_ObjectList[ i ];

		if ( !isSceneTriangleObject( pTriangleObject ) ) 
			continue;

		/**
		 *	Scene ��ü�� �ﰢ������ BoundingBox �� ���Ѵ�.
		 */
		bbox += (*pTriangleObject->getBoundingBox());
		totalCount += pTriangleObject->getTriangleCount();

	}

	/** 
	 *	2. scene ��ü�� �ﰢ���� ���� ������ �Ҵ��ϰ�, �����Ѵ�. 
	 */
	pList->reserve( totalCount );
	totalCount = 0;

	for ( int i = 0; i < (int) m_ObjectList.size(); ++i ) {

		pTriangleObject = (GPolygonObject*) m_ObjectList[ i ];

		if ( !isSceneTriangleObject( pTriangleObject ) ) 
			continue;

		pTriangleObject->getTriangleList( pList, i, totalCount );

	}

	return pList;
}

bool GScene::isSceneTriangleObject( GPolygonObject *pObject )
{
	if ( !pObject->isVisible() || pObject->isDebugObject() || 
		 pObject->getPolygonType() != typePolygonTriangle ||
		 !pObject->isIntersection() ) return false;
	return true;
}

int GScene::getGeometryChangeTimestamp()
{
	return m_iGeometryChangeTimestamp;
}

void GScene::setBackFaceCulling( bool flag )
{
	m_bBackFaceCulling = flag;
}

bool GScene::isBackFaceCulling()
{
	return m_bBackFaceCulling;
}

void GScene::setUseTexture( bool flag )
{
	m_bUseTexture = flag;
}

bool GScene::isUseTexture()
{
	return m_bUseTexture;
}

void GScene::setPhotonMappingOption( GPhotonMappingOption option )
{
	m_PhotonMappingOption = option;
}

GPhotonMappingOption* GScene::getPhotonMappingOption()
{
	return &m_PhotonMappingOption;
}

GRayProfilerOption* GScene::getOpenGLOption()
{
	return &m_OpenGLOption;
}

void GScene::setSceneBasePath( const char* path )
{
	strncpy( m_szSceneBasePath, path, MAX_PATH_LENGTH - 1 );
	m_szSceneBasePath[ MAX_PATH_LENGTH - 1 ] = 0x00;
}

const char* GScene::getSceneBasePath()
{
	return m_szSceneBasePath;
}

bool GScene::saveImage( const char* postfix )
{
	char resultfile[ 2048 ] = { 0x00, };

	sprintf( resultfile, "%s%c%s%s.bmp", m_szOutputPath, FILE_SEPARATOR, "result", postfix );

	return m_pImageBuffer->saveImage( resultfile );
}

bool GScene::saveImageFullPath( const char* fullpath )
{
	return m_pImageBuffer->saveImage( fullpath );
}

void GScene::setRun10Times( bool flag )
{
	m_bRun10Times = flag;
}

bool GScene::IsRun10Times()
{
	return m_bRun10Times;
}

void GScene::setProfileResultPath( const char* path )
{
	strcpy( m_szProfileResultPath, path );
}

const char* GScene::getProfileResultPath()
{
	return m_szProfileResultPath;
}

void GScene::setProfileFlag( bool flag )
{
	m_bProfileFlag = flag;
}

bool GScene::IsProfileFlag()
{
	return m_bProfileFlag;
}

void GScene::setTestFlag( bool flag )
{
	m_bTestFlag = flag;
}

bool GScene::IsTestFlag()
{
	return m_bTestFlag;
}

/**
 *	Scene ���� ��ü���� intersection �� �����ؾ� �ϰ�,
 *	trianglulation �� �����ϴ� object �� GTriangleWrapperList ��
 *	����� �����Ѵ�.
 */
/*
GTriangleWrapperList *GScene::precalcBVHTriangleList( GBoundingBox &bbox )
{
	int totalCount = 0;
	int tri_index  = 0;
	GTriangleWrapperList *pList = new GTriangleWrapperList();
	GPolygonObject* pTriangleObject = NULL;

	bbox.setMax( GVector( -1000000.0f, -1000000.0f, -1000000.0f ) );
	bbox.setMin( GVector( 1000000.0f, 1000000.0f, 1000000.0f ) );

	///**
	// *	Scene ���� Object ��κ��� �ﰢ�� ������ ���´�.
	// *	1. ���� �� �ﰢ���� ������ ���Ѵ�.
	
	for ( int i = 0; i < (int) m_ObjectList.size(); ++i ) {

		pTriangleObject = (GPolygonObject*) m_ObjectList[ i ];

		if ( !isSceneTriangleObject( pTriangleObject ) ) 
			continue;

		// �� �ﰢ������ bounding box�� ���Ѵ�.
		aryAABB[tri_index++] = (*pTriangleObject->getBoundingBox());

		///**
		// *	Scene ��ü�� �ﰢ������ BoundingBox �� ���Ѵ�.
	
		bbox += (*pTriangleObject->getBoundingBox());		
		totalCount += pTriangleObject->getTriangleCount();

	}

	//
	 //*	2. scene ��ü�� �ﰢ���� ���� ������ �Ҵ��ϰ�, �����Ѵ�. 
	 
	pList->reserve( totalCount );
	totalCount = 0;

	for ( int i = 0; i < (int) m_ObjectList.size(); ++i ) {

		pTriangleObject = (GPolygonObject*) m_ObjectList[ i ];

		if ( !isSceneTriangleObject( pTriangleObject ) ) 
			continue;

		pTriangleObject->getTriangleList( pList, i, totalCount );

	}

	return pList;
}
*/
