#pragma once

//--------------------------------------------------------------------------//
//																			//
//	��ü Scene																//
//																			//
//--------------------------------------------------------------------------//
#include "GBase.h"
#include <vector>
#include "GObject.h"
#include "GLight.h"
#include "GCamera.h"
#include "GDimension.h"
#include "GTriangleWrapper.h"
#include "GSpatialStructure.h"
#include "GImageBuffer.h"
#include "GTriangleWrapperList.h"
#include "GPhotonMappingOption.h"
#include "GRayProfilerOption.h"
#include "GBoundingBox.h"
#include "GCriticalSection.h"

using namespace std;

#define MAX_PATH_LENGTH	2048

/**
 *	face ����.
 */
typedef enum {
	faceCW = 0,			//	�ð����
	faceCCW = 1,		//	�ݽð����
} enumFrontFace;

typedef enum {
	adaptiveFixed = 0,			//	�߰������� super-sampling �ؾ��� ������ ������ 4x4 �� ��� ���.
	adaptiveSubpixel = 1		//	�߰������� super-sampling �ؾ��� ������ sub 4 pixels �� ��� ���� �����ϴ� ���.
} enumAdaptiveSamplingType;

typedef enum {
	SAH  = 0,			//	SAH (�⺻��)
	EMPTY_SAH = 1,		//	EMPTY_SAH
} enumKdTreeType;

typedef enum {
	USE_NONE	  = 0,
	USE_KDTREE    = 1,		//	Kd-Tree (�⺻��)
	USE_BVH       = 2,		//	BVH
	USE_GRID      = 3,		//	Grid
} enumSpatialStructureType;

#define COMPARE_PRIMARY_OID					1
#define COMPARE_PRIMARY_NORMAL				2
#define COMPARE_PRIMARY_SHADOW				4
#define COMPARE_PRIMARY_TEXTURE				8

#define COMPARE_SECONDARY_OID				16
#define COMPARE_SECONDARY_NORMAL			32
#define COMPARE_SECONDARY_SHADOW			64
#define COMPARE_SECONDARY_TEXTURE			128

#define COMPARE_ETC_REGION					256

#define COMPARE_ONLY_PIXEL_COLOR			512

class GKDTreeStructure;						// Kd-Tree
class GBVHStructure;						// BVH
class GGridStructure;						// Grid

class GScene
{
private:
	int m_iSceneNumber;
	int m_LoadedCameraCount;

	char m_szSceneName[1024];
	/**
	 *	Scene Rendering Option
	 */
	char m_szVersion[MAX_PATH_LENGTH];
	
	char m_szSceneBasePath[MAX_PATH_LENGTH];
	char m_szOutputPath[MAX_PATH_LENGTH];
	char m_szTexturePath[MAX_PATH_LENGTH];

	int m_iGeometryChangeTimestamp;			//	Scene �� Object, Light ������ ����ɶ�����+
	int m_iLastConvertRenderScene;

	enumSpatialStructureType m_LastUseSpatialStructure;
	enumSpatialStructureType m_CurrUseSpatialStructure;
	int m_iLastGeomTimestamp_For_SpatialStructure[16];		// enumSpatialStructureType �� ũ�⸸ŭ �ʿ�

	GDimension m_Resolution;
	GDimension m_SuperSampling;
	GDimension m_RenderingBlock;

	bool m_bJittering;
	bool m_bBackFaceCulling;
	bool m_bUseTexture;
	bool m_bLocalShading;
	bool m_bShadow;
	int m_iMaxReflectionDepth;
	enumFrontFace m_FrontFace;
	GColor m_globalAmbient;

	GImageBuffer *m_pImageBuffer;
	GImageBuffer *m_pDirectIllumImageBuffer;
	GImageBuffer *m_pIndirectIllumImageBuffer;

	int m_iCPUThreadCount;					// ������ ����
	GDimension m_GPUBlockSize;				// GPU block  size
	GDimension m_CPUPacketSize;				// CPU packet size : 1x1, 2x2, 4x4

	float m_fFPS, m_fFPS2;
	bool m_bOpenGLLoadTexture;

	// ----------------------------------------------------------------------
	// Spatial structure
	// ----------------------------------------------------------------------
	int m_bKDTreeFileType;
	bool m_bKDTreeFileLoad;
	bool m_bKDTreeFileSave;
	char m_szKDTreeLoadFilePath[MAX_PATH_LENGTH];
	char m_szKDTreeSaveFilePath[MAX_PATH_LENGTH];
	GKDTreeStructure	*m_pKDTree;
	GKDTreeStructure	*m_pEmptyKDTree;
	GBVHStructure		*m_pBVH;
	GGridStructure		*m_pGrid;

	// ----------------------------------------------------------------------
	// Photon mapping
	// ----------------------------------------------------------------------
	GPhotonMappingOption m_PhotonMappingOption;
	GRayProfilerOption m_OpenGLOption;

	bool m_bAntialiasingFilter;
	bool m_bBloomingFilter;
	float m_fBloomingRadius;
	float m_fBloomingWeight;

	bool m_bGrayScaleFilter;
	bool m_bEdgeDetectionFilter;
	bool m_bBlurFilter;

	// ----------------------------------------------------------------------
	// Adaptive sampling
	// ----------------------------------------------------------------------
	enumAdaptiveSamplingType m_AdaptiveSamplingType;
	int m_AdaptiveSamplingCompareType;
	bool m_bSamplingDebugInfo;

	float m_fPrimaryOIDRegionColorThreshold;
	float m_fPrimaryNormalRegionColorThreshold;
	float m_fPrimaryShadowRegionColorThreshold;
	float m_fPrimaryTextureRegionColorThreshold;
	float m_fSecondaryOIDRegionColorThreshold;
	float m_fSecondaryNormalRegionColorThreshold;
	float m_fSecondaryShadowRegionColorThreshold;
	float m_fSecondaryTextureRegionColorThreshold;
	float m_fEtcRegionColorThreshold;
	float m_fOnlyColorThreshold;

	float m_fAdaptiveDetectionStageTime;
	float m_fAdaptiveRayRate;

protected:
	static int g_iObjectNumberGen;

	GCamera	m_RenderCamera;
	GCamera	m_InitRenderCamera;

	vector<GObject*> m_ObjectList;
	vector<GObject*> m_SelecteGObjectList;
	vector<GLight*>	 m_LightList;
	vector<GCamera*> m_CameraList;

	GCriticalSection	m_ObjectListCS;

public:
	GScene(void);
	virtual ~GScene(void);

	void setSceneName( const char* name );
	const char* getSceneName();

	int getSceneNumber();

	/**
	 *	Scene Rendering Option
	 */
	void setVersion( const char* version );
	const char* getVersion();
	void setSceneBasePath( const char* path );
	void setOutputPath( const char* path );
	void setTexturePath( const char* path );
	const char* getSceneBasePath();
	const char* getOutputPath();
	const char* getTexturePath();

	bool saveImage( const char* postfix );
	bool saveImageFullPath( const char* fullpath );

	int getGeometryChangeTimestamp();

	void setResolution( int width, int height );
	GDimension getResolution();
	void setSuperSampling( int x, int y );
	GDimension getSuperSampling();
	void setRenderingBlock( int x, int y );
	GDimension getRenderingBlock();

	void setEnableJittering( bool flag );
	bool isEnableJittering();
	void setBackFaceCulling( bool flag );
	bool isBackFaceCulling();
	void setUseTexture( bool flag );
	bool isUseTexture();
	void setEnableLocalShading( bool flag );
	bool isEnableLocalShading();
	void setEnableShadow( bool flag );
	bool isEnableShadow();
	void setMaxReflectionDepth( int depth );
	int getMaxReflectionDepth();
	void setFrontFace( enumFrontFace face );
	enumFrontFace getFrontFace();
	void setGlobalAmbient( GColor& color );
	GColor getGlobalAmbient();

	/**
	 *	Scene �� �������� ����� ������ �ִ� Image Buffer.
	 */
	GImageBuffer *getImageBuffer();
	GImageBuffer *getDirectIllumImageBuffer();
	GImageBuffer *getIndirectIllumImageBuffer();

	void setCPUThreadCount( int count );
	int getCPUThreadCount();
	void setGPUBlockSize( int x, int y );
	GDimension getGPUBlockSize();
	void setCPUPacketSize( int x, int y );
	GDimension getCPUPacketSize();

	void setOpenGLLoadTexture( bool flag );
	bool isOpenGLLoadTexture();

	float getFPS();
	void setFPS( float fps );
	float getFPS2();
	void setFPS2( float fps );

	// ----------------------------------------------------------------------
	// Spatial structure
	// ----------------------------------------------------------------------
	void setKdTreeFileType( int type );
	int getKdTreeFileType();
	void setKdTreeFileLoad( bool flag );
	bool isKdTreeFileLoad();
	void setKdTreeFileSave( bool flag );
	bool isKdTreeFileSave();
	void setKdTreeLoadFilePath( const char* path );
	const char* getKdTreeLoadFilePath();
	void setKdTreeSaveFilePath( const char* path );
	const char* getKdTreeSaveFilePath();

	GKDTreeStructure*	getKDTreeStructure(void);
	GBVHStructure*		getBVHStructure(void);
	GGridStructure*		getGridStructure(void);

	void setUseSpatialStructure( enumSpatialStructureType type );

	/**
	 * Empty KD-Tree �� ����.
	 * ���� Object KD Tree �� ������ ��� Object KD Tree �� ������.
	*/
	GError buildEmptyKdTree();

	/**.
	 * Object �� KD-Tree �� ����
	 * Empty KD-Tree �� ���� ��� ��ü scene �� ���ؼ� �����.
	 * Empty KD-Tree �� ������ �ϸ� �ȵ�.
	*/
	GError buildObjectKdTree();

	// ----------------------------------------------------------------------
	// Adaptive sampling
	// ----------------------------------------------------------------------
	void setAdaptiveSamplingType( enumAdaptiveSamplingType type );
	enumAdaptiveSamplingType getAdaptiveSamplingType();

	void setPrimaryOIDRegionColorThreshold( float f );
	float getPrimaryOIDRegionColorThreshold();
	void setPrimaryNormalRegionColorThreshold( float f );
	float getPrimaryNormalRegionColorThreshold();
	void setPrimaryShadowRegionColorThreshold( float f );
	float getPrimaryShadowRegionColorThreshold();
	void setPrimaryTextureRegionColorThreshold( float f );
	float getPrimaryTextureRegionColorThreshold();

	void setSecondaryOIDRegionColorThreshold( float f );
	float getSecondaryOIDRegionColorThreshold();
	void setSecondaryNormalRegionColorThreshold( float f );
	float getSecondaryNormalRegionColorThreshold();
	void setSecondaryShadowRegionColorThreshold( float f );
	float getSecondaryShadowRegionColorThreshold();
	void setSecondaryTextureRegionColorThreshold( float f );
	float getSecondaryTextureRegionColorThreshold();

	void setEtcRegionColorThreshold( float f );
	float getEtcRegionColorThreshold();

	void setOnlyColorThreshold( float f );
	float getOnlyColorThreshold();

	void setAdaptiveDetectionStageTime( float t );
	float getAdaptiveDetectionStageTime();
	void setAdaptiveRayRate( float r );
	float getAdaptiveRayRate();

	void setLowLevelAdaptiveSamplingThreshold();
	void setGoodLevelAdaptiveSamplingThreshold();
	void setHighLevelAdaptiveSamplingThreshold();
	void setVeryHighLevelAdaptiveSamplingThreshold();
	void setVeryHighLevelExceptTextureAdaptiveSamplingThreshold( float primaryColor, float tColor );

	void setAdaptiveSamplingCompareType( int compare );
	int getAdaptiveSamplingCompareType();
	void setEnableSamplingDebugInfo( bool flag );
	bool isEnableSamplingDebugInfo();

	void setUseAntialiasingFilter( bool flag );
	bool isUseAntialiasingFilter();
	void setUseBlurFilter( bool flag );
	bool isUseBlurFilter();
	void setUseEdgeDetectionFilter( bool flag );
	bool isUseEdgeDetectionFilter();
	void setUseGrayScaleFilter( bool flag );
	bool isUseGrayScaleFilter();

	void setBloomingFilter( bool flag );
	bool isBloomingFilter();
	void setBloomingRadius( float radius );
	float getBloomingRadius();
	void setBloomingWeight( float w );
	float getBloomingWeight();

	GCamera* getRenderCamera();
	void setRenderCamera( const GCamera* pCamera );
	GCamera* getInitRenderCamera();
	void setInitRenderCamera( const GCamera* pCamera );

	GTextureManager *getTextureManager();

	/**
	 *	�ε��� Scene �����͸� ������� �ʱ�ȭ �Ұ��� �ִٸ�
	 *	�����Ѵ�.
	 */
	bool initalize();

	/**
	 *	Light �߰�. ������ ������ �߰��ؾ� �Ѵ�. ���߿�
	 *	scene ���� ���� ��Ŵ.
	 */
	void addLight( GLight *pLight );
	
	/**
	 *	Light ��� ��������
	 */
	const vector<GLight*>* getLightList();

	/**
	 *	Camera �߰�. ������ ������ �߰��ؾ� �Ѵ�. ���߿�
	 *	scene ���� ���� ��Ŵ.
	*/
	void addCamera( GCamera *pCamera );

	/**
	 *	Camera ��� ��������
	*/
	const vector<GCamera*>* getCameraList();

	/** 
	 *	Scene �� ��ü �߰� 
	 */
	virtual GError addObject( GObject* pObject );

	/**
	 *	Scene ���� ��ü ����
	 */
	virtual void removeObject( GObject* pObject );

	/**
	 *	name �̸��� ���� Scene ���� ��ü ����
	 */
	virtual void removeObject( const char* name );

	/**
	 *	Scene �� �ִ� ��� ��ü ����
	 */
	virtual void clearObject();
	virtual void clearDebugObject();

	/**
	 *	index �� �ش��ϴ� ��ü ��������
	 */
	GObject* getObject( int index );

	/**
	 *	���� ��ü ���� ����.
	 */
	int getObjectCount();

	/**
	 *	��ü ��� vector ����.
	 */
	const vector<GObject*>* getObjectList();

	/**
	 * ��� ��ü�� deselect ���·� �����.
	 */
	void deselectAllObject();

	/**
	 *	Ư�� ��ü�� deselect ���·� �����.
	 */
	void deselectObject( GObject* pObject );

	/**
	 *	��ü�� select ��Ų��.
	 */
	void selectObject( GObject* pObject );

	/**
	 *	select �� ��ü ���� ����.
	 */
	int getSelectedGObjectCount();

	/**
	 *	���� select �� ��ü�� ù ��° ��ü ����.
	 */
	GObject* getSelectedGObject();

	/**
	 *	���� select �� ��� ��ü ����.
	 */
	vector<GObject*>* const getSelectedGObjectList();

	/**
	 *	object Number �� �ش��ϴ� ��ü ����.
	 */
	GObject* getObjectByNumber( int objectNumber );

	/**
	 *  center of selected objects
	*/
	GVector getCenterOfSelectedGObjects();

	/**
	 *  bounding box of selected objects
	*/
	GBoundingBox getBoundingBoxOfSelectedGObjects();

	/**
	 *	�������� �����ϱ� ���� Scene �� �ʱ�ȭ �۾��� �����Ѵ�.
	 *	Object �� matrix �� ��� �����ؼ� ��� �����͸� World ��ǥ���
	 *	��ȯ�� �д�. Rendering �� �����ϱ� ���� �׻� ���� ó���ؾ���.
	 */
	GError convertRenderScene();

	GTriangleWrapperList *createSceneTriangleList( GBoundingBox &bbox );

	bool isSceneTriangleObject( GPolygonObject *pObject );

	void setPhotonMappingOption( GPhotonMappingOption option );
	GPhotonMappingOption* getPhotonMappingOption();
	
	GRayProfilerOption* getOpenGLOption();

	/**
	 *	�������� 10ȸ �����ϵ��� flag ����
	 */
	bool m_bRun10Times;
	void setRun10Times( bool flag );
	bool IsRun10Times();
	char m_szProfileResultPath[MAX_PATH_LENGTH];
	void setProfileResultPath( const char* path );
	const char* getProfileResultPath();
	bool m_bProfileFlag;
	void setProfileFlag( bool flag );
	bool IsProfileFlag();

	/**
	 *	�׽�Ʈ �뵵 flag setting
	 */
	bool m_bTestFlag;
	void setTestFlag( bool flag );
	bool IsTestFlag();
};
