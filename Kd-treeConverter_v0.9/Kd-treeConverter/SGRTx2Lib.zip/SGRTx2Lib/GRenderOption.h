#pragma once

/**
 *	Rendering Option ����.
 *
 *	by graphicsian.
 */
class GRenderOption
{
public:
	GRenderOption(void);
	~GRenderOption(void);
};
