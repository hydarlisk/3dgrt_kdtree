#include "GGPURayTracerForPaper.h"
#include "GGPURayTracerForPaper.h"
#include "GSpatialStructure.h"
#include "GKDTreeStructure.h"
#include "GPointLight.h"
#include "GRenderCommon.h"
#include "math.h"

GGPURayTracerForPaper::GGPURayTracerForPaper()
{
	m_iOldSceneNumber = 0;
	m_pCudaRenderPipeline = NULL;
	m_iSceneTimestamp = -1;
	m_pScene = NULL;
}

GGPURayTracerForPaper::~GGPURayTracerForPaper(void)
{
	uninitialize();
}

void GGPURayTracerForPaper::uninitialize()
{
	if ( m_pCudaRenderPipeline ) {
		delete m_pCudaRenderPipeline;
	}
}

/**
 *	scene ������ �籸���ؾ��Ҷ� �ʱ�ȭ�Ѵ�.
 */
GError GGPURayTracerForPaper::initialize( GScene *pScene )
{
	GError error;
	m_pScene = pScene;

	if ( m_iOldSceneNumber != pScene->getSceneNumber() || 
		 m_iSceneTimestamp != pScene->getGeometryChangeTimestamp() ||
		 m_oldResolution != pScene->getResolution() ) {

		if ( m_pCudaRenderPipeline ) {
			delete m_pCudaRenderPipeline;
		}

		cuScene cuSceneInfo;
		cuSceneInfo.globalAmbient = make_float3( pScene->getGlobalAmbient().r, 
												 pScene->getGlobalAmbient().g,
												 pScene->getGlobalAmbient().b );
		cuSceneInfo.iResolutionX = pScene->getResolution().x;
		cuSceneInfo.iResolutionY = pScene->getResolution().y;
		cuSceneInfo.iSuperSamplingX = pScene->getSuperSampling().x;
		cuSceneInfo.iSuperSamplingY = pScene->getSuperSampling().y;
		cuSceneInfo.iBlockSizeX = pScene->getGPUBlockSize().x;
		cuSceneInfo.iBlockSizeY = pScene->getGPUBlockSize().y;
		cuSceneInfo.bEnableLocalShading = pScene->isEnableLocalShading();
		cuSceneInfo.bEnableShadow = pScene->isEnableShadow();
		cuSceneInfo.bEnableTexture = pScene->isUseTexture();
		cuSceneInfo.iShadowRay = 1;

		m_pCudaRenderPipeline = new cudaRenderPipeline();
		int maxRay = cuSceneInfo.iResolutionX * cuSceneInfo.iResolutionY;

		error = m_pCudaRenderPipeline->initialize( cuSceneInfo, maxRay );
		if ( error != errorNo )
			return error; 

		/**
		 *	Light ���� ����. ������ �ʿ�����Ƿ� ����.
		 */
		int lightCount = 0;
		cuLight* pLight = GRenderCommon::makeCudaLightInfo( pScene, &lightCount, m_pCudaRenderPipeline );
		error = m_pCudaRenderPipeline->setLightInfo( pLight, lightCount );
		free( pLight );

		if ( error != errorNo )
			return error;

		/** 
		 *	�� ���������, kdtree ������ �̷��� �ؼ� cuda �� �ѱ�. 
		 */ 
		error = pScene->getKDTreeStructure()->makeCudaRenderStructureInfo( m_pCudaRenderPipeline );
		if ( error != errorNo )
			return error;

		/** blooming ȿ���� �����ϱ⸦ ���Ѵٸ� �ʱ�ȭ �ص�.*/
		error = m_pCudaRenderPipeline->initBloomingFilter( m_pScene->getBloomingRadius(),
														   m_pScene->getBloomingWeight() );
		if ( error != errorNo )
			return error;

		m_pCudaRenderPipeline->printStatusInfo();
	}

	/**
	 *	���� Renderer �� ó���� Scene �� ����Ѵ�.
	 */
	m_iOldSceneNumber = pScene->getSceneNumber();
	m_iSceneTimestamp = pScene->getGeometryChangeTimestamp();
	m_oldResolution = pScene->getResolution();

	return errorNo;
}

GError GGPURayTracerForPaper::rendering( GScene *pScene, bool isDebug )
{
	GError error;

	/** 
	 *	Scene �� ���� geometry ���¿��� ���Ѱ� �ִ��� üũ�ؼ� �ִٸ�
	 *	SpatialStructure �� �籸���Ѵ�.
	 */
	error = initialize( pScene );
	if ( error != errorNo ) {
		GLogManager::logging( LOG_ERROR, "can't initialize rendering\n" );
		return error;
	}

	/** rendering option ���� */
	cuScene cuSceneInfo;
	cuSceneInfo.globalAmbient = make_float3( pScene->getGlobalAmbient().r, 
											 pScene->getGlobalAmbient().g,
											 pScene->getGlobalAmbient().b );
	cuSceneInfo.iResolutionX = pScene->getResolution().x;
	cuSceneInfo.iResolutionY = pScene->getResolution().y;
	cuSceneInfo.iSuperSamplingX = pScene->getSuperSampling().x;
	cuSceneInfo.iSuperSamplingY = pScene->getSuperSampling().y;
	cuSceneInfo.iBlockSizeX = pScene->getGPUBlockSize().x;
	cuSceneInfo.iBlockSizeY = pScene->getGPUBlockSize().y;
	cuSceneInfo.bEnableLocalShading = pScene->isEnableLocalShading();
	cuSceneInfo.bEnableTexture = pScene->isUseTexture();
	cuSceneInfo.bEnableShadow = pScene->isEnableShadow();
	cuSceneInfo.iShadowRay = 1;

	m_pCudaRenderPipeline->setSceneInfo( cuSceneInfo );

	cuThreshold cuThresholdInfo;
	cuThresholdInfo.primaryOIDRegionColorThreshold = pScene->getPrimaryOIDRegionColorThreshold();
	cuThresholdInfo.primaryNormalRegionColorThreshold = pScene->getPrimaryNormalRegionColorThreshold();
	cuThresholdInfo.primaryShadowRegionColorThreshold = pScene->getPrimaryShadowRegionColorThreshold();
	cuThresholdInfo.primaryTextureRegionColorThreshold = pScene->getPrimaryTextureRegionColorThreshold();
	cuThresholdInfo.secondaryOIDRegionColorThreshold = pScene->getSecondaryOIDRegionColorThreshold();
	cuThresholdInfo.secondaryNormalRegionColorThreshold = pScene->getSecondaryNormalRegionColorThreshold();
	cuThresholdInfo.secondaryShadowRegionColorThreshold = pScene->getSecondaryShadowRegionColorThreshold();
	cuThresholdInfo.secondaryTextureRegionColorThreshold = pScene->getSecondaryTextureRegionColorThreshold();
	cuThresholdInfo.etcRegionColorThreshold = pScene->getEtcRegionColorThreshold();
	cuThresholdInfo.onlyColorThreshold = pScene->getOnlyColorThreshold();

	m_pCudaRenderPipeline->setThresholdInfo( cuThresholdInfo );


	GImageBuffer *pImageBuffer = pScene->getImageBuffer();

	int depth = 0;
	int m_iMaxDepth = pScene->getMaxReflectionDepth();
	int atLeastOneRay = 0;

	cuCamera camera = calCameraInfo( m_pScene );

	m_pCudaRenderPipeline->clearFrameBuffer();
	m_pCudaRenderPipeline->setCameraInfo( &camera );

	GTimer timer1;
	timer1.start();

	float detectionTime = 0.0f;
	float rayRate = 0.0f;

	error = m_pCudaRenderPipeline->fixedOption_doSelectiveAndAdaptiveSamplingRayTracing( 
							m_iMaxDepth,
							pScene->getSuperSampling().x, pScene->getSuperSampling().y,
							pScene->isEnableJittering(),
							pScene->isEnableSamplingDebugInfo(),
							pScene->getAdaptiveSamplingCompareType(),
							pScene->isEnableShadow(),
							&detectionTime, 
							&rayRate );

	//error = m_pCudaRenderPipeline->doSelectiveAndAdaptiveSamplingRayTracing( 
	//						m_iMaxDepth, 
	//						pScene->getSuperSampling().x, pScene->getSuperSampling().y,
	//						pScene->isEnableJittering(),
	//						pScene->isEnableSamplingDebugInfo(),
	//						pScene->getAdaptiveSamplingCompareType(),
	//						pScene->isEnableShadow(),
	//						&detectionTime, 
	//						&rayRate );

	if ( error != errorNo ) {
		GLogManager::logging( LOG_FATAL, "Rendering Error, %s\n", GErrorManager::getGErrorString( error ) );
		return errorNo;
	}

	pScene->setAdaptiveDetectionStageTime( detectionTime );
	pScene->setAdaptiveRayRate( rayRate );

	if ( m_pScene->isBloomingFilter() )
		m_pCudaRenderPipeline->bloomingFiltering();

	if ( m_pScene->isUseAntialiasingFilter() )
		m_pCudaRenderPipeline->antialiasingFiltering();

	if ( m_pScene->isUseBlurFilter() )
		m_pCudaRenderPipeline->blurringFiltering();

	if ( m_pScene->isUseEdgeDetectionFilter() )
		m_pCudaRenderPipeline->sobelMethodFiltering();

	if ( m_pScene->isUseGrayScaleFilter() )
		m_pCudaRenderPipeline->grayScaleFiltering();

	timer1.end();

	m_pCudaRenderPipeline->getFrameBuffer( pImageBuffer->getBuffer() );
	m_pScene->setFPS( 1.0f / timer1.getElapsedTime() );

	GLogManager::logging( LOG_DEBUG, "traceRayFullBounce time : %f sec. traced depth = %d\n", timer1.getElapsedTime(), depth );

	return errorNo;

}

cuCamera GGPURayTracerForPaper::calCameraInfo( GScene *pScene )
{
	GDimension resolution = pScene->getResolution();
	GDimension SuperSampling = pScene->getSuperSampling();
	GCamera* pCamera = pScene->getRenderCamera();
	float aspect = (float) resolution.x / (float) resolution.y;
	float cameraPlaneHeight = 2.0f * pCamera->getNear() * tanf( ( pCamera->getFovy() * 0.5f ) * G_TO_RADIAN );
	float cameraPlaneWidth = aspect * cameraPlaneHeight;

	cuCamera camera;

	camera.eye = make_float3( pCamera->getEye().x, pCamera->getEye().y, pCamera->getEye().z );
	camera.u = make_float3( pCamera->getUVec().x, pCamera->getUVec().y, pCamera->getUVec().z );
	camera.v = make_float3( pCamera->getVVec().x, pCamera->getVVec().y, pCamera->getVVec().z );
	camera.n = make_float3( pCamera->getNVec().x, pCamera->getNVec().y, pCamera->getNVec().z );
	camera.fnear = pCamera->getNear();

	GVector startPoint = pCamera->getEye() - ( pCamera->getNVec() * camera.fnear ) +
						( pCamera->getVVec() * ( cameraPlaneHeight * 0.5f ) ) -
						( pCamera->getUVec() * ( cameraPlaneWidth * 0.5f ) );
	camera.startPoint = make_float3( startPoint.x, startPoint.y, startPoint.z );

	camera.stepX = cameraPlaneWidth / (float)resolution.x;
	camera.stepY = cameraPlaneHeight / (float)resolution.y;

	return camera;
}

/**
 *	���� scene ������ ������� ray index �� �ش��ϴ� ray ��
 *	image ���� �� pixel �� �ش������� ����Ѵ�.
 */
int GGPURayTracerForPaper::toImageIndex( GScene *pScene, int rayIndex, int *x, int *y )
{
	/** ray index �� x,y ��ǥ�� ��ȯ */
	(*x) = rayIndex % ( pScene->getResolution().x );
	(*y) = rayIndex / ( pScene->getResolution().x );
	
	/** �ٽ� image index �� ��ȯ */
	return (*y) * pScene->getResolution().x + (*x);
}


