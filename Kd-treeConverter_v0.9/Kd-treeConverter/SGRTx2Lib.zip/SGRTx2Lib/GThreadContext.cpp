#include "GThreadContext.h"

GThreadContext::GThreadContext( UINT uiThreadID )
{
	/**
	 *	������ ID
	 */
	m_uiThreadID = uiThreadID;

//	m_bHideObject = GLOBAL_HIDE_OBJECT_SET;
}

GThreadContext::~GThreadContext(void)
{
}

UINT GThreadContext::getThreadID()
{
	return m_uiThreadID;
}

/**
 *	Thread �� WorkNumber �� �����Ѵ�.
 */
void GThreadContext::setWorkNumber( UINT nWork )
{
	m_uiWorkNumber = nWork;
}

/**
 *	Thread �� WorkNumber �� ��ȯ�Ѵ�.
 */
UINT GThreadContext::getWorkNumber()
{
	return m_uiWorkNumber;
}

//void GThreadContext::setCalculateShadow(bool flag)
//{
//	m_bCalculateShadow = flag;
//}
//bool GThreadContext::getCalculateShadow(void)
//{
//	return m_bCalculateShadow;
//}
//
//void GThreadContext::setHideObject(bool flag)
//{
//	m_bHideObject = flag;
//}
//
//bool GThreadContext::getHideObject(void)
//{
//	return m_bHideObject;
//}